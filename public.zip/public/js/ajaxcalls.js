$(function () {
      
    $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
    });
});

$('#step1Submit').click(function (e) {
    e.preventDefault();
    // $(this).html('Sending..');
    $.ajax({
        data: $('#step1form').serialize(),
        url: "/save_step1",
        type: "POST",
        dataType: 'json',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function (data) {
            console.log('success:', data);
        },
        error: function (data) {
            console.log('Error:', data);
        }
    });
});