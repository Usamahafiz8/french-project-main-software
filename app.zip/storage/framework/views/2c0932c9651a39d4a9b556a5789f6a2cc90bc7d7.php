<?php $__env->startSection('title','Auditor'); ?>   

   
<?php $__env->startSection('contentdata'); ?>
<?php
$customerId = Request::route('id');
?>

<div class="wizard" style="padding:24px">
               <div class="wizard-progress">
                 <div class="progress">
                   <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 33%;"></div>
                 </div>
                 <ul class="nav nav-tabs">
                   <li class="nav-item active" id="firsttab"><a class="nav-link" href="#step1" data-toggle="tab">1</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step2" data-toggle="tab">2</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step3" data-toggle="tab">3</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step4" data-toggle="tab">4</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step5" data-toggle="tab">5</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step6" data-toggle="tab">6</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step7" data-toggle="tab">7</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step8" data-toggle="tab">8</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step9" data-toggle="tab">9</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step10" data-toggle="tab">10</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step11" data-toggle="tab">11</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step12" data-toggle="tab">12</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step13" data-toggle="tab">13</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step14" data-toggle="tab">14</a></li>
                   <li class="nav-item"><a class="nav-link" href="#step15" data-toggle="tab">15</a></li>
                   
                 </ul>
               </div>
               <!-- <?php echo $__env->make('forms.select', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
               <form role="form" class="form-horizontal">
                 <div class="tab-content">
                   <!---tab pane active end---->
                   <div class="tab-pane active" role="tabpanel" id="step1">
                   <?php echo $__env->make('forms.step1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </div>
                  <!---tab pane active end---->
                   <div class="tab-pane" role="tabpanel" id="step2">
                   <?php echo $__env->make('forms.step2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step3">
                   <?php echo $__env->make('forms.step3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step4">
                   <?php echo $__env->make('forms.step4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step5">
                   <?php echo $__env->make('forms.step5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </div>
                   
                   <div class="tab-pane" role="tabpanel" id="step6">
                    <?php echo $__env->make('forms.step6', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </div>
 
                   <div class="tab-pane" role="tabpanel" id="step7">
                   <?php echo $__env->make('forms.step7', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step8">
                   <?php echo $__env->make('forms.step8', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step9">
                   <?php echo $__env->make('forms.step9', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step10">
                   <?php echo $__env->make('forms.step10', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step11">   
                   <?php echo $__env->make('forms.step11', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step12">
                   <?php echo $__env->make('forms.step12', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                   </div>
                    
                   <div class="tab-pane" role="tabpanel" id="step13">
                   <?php echo $__env->make('forms.step13', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step14">
                   <?php echo $__env->make('forms.step14', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                   </div>

                   <div class="tab-pane" role="tabpanel" id="step15">
                   <?php echo $__env->make('forms.step15', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                   </div> 

                 </div>
               </form>
             </div>
            <!---Wizard area end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cybillne/public_html/resources/views/customerDetails.blade.php ENDPATH**/ ?>