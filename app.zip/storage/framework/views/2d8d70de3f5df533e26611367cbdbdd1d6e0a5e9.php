<html>
    <head>
        <style>
            /** Define the margins of your page **/
            @page {
                margin: 60px 2px;
            }

            header{
                position: fixed;
                top: -150px;
                left: -50px;
                right: 0px;
                height: auto;
                
                /* font-size: 20px !important; */

                /** Extra personal styles **/
                /* background-color: #008B8B; */
                /* color: white; */
                line-height: 505px;
            }
            .header_logo{
                width:905px;
                height:auto
            }
            /* footer {
                position: fixed; 
                bottom: -60px; 
                left: 0px; 
                right: 0px;
                height: 50px; 
                font-size: 20px !important;

                background-color: #008B8B;
                color: white;
                text-align: center;
                line-height: 35px;
            } */
        </style>
    </head>
    <body>
        <!-- Define header and footer blocks before your content -->
        <header>
            <img alt="" class="header_logo" src="<?php echo e(public_path().'/test1.png'); ?>">
        </header>

        <!-- <footer>
            Copyright © <?php echo date("Y");?> 
        </footer> -->

        <!-- Wrap the content of your PDF inside a main tag -->
        <main>
            <br><br><br><br>
            <p style="page-break-after: always;">
                paragraph 1  sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
            <br><br><br><br>
            <p style="page-break-after: always;">
                paragraph 2  sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
            
            <p style="page-break-after: never;">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>

        </main>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\french-project-responsiveness-main\resources\views/formPDF2.blade.php ENDPATH**/ ?>